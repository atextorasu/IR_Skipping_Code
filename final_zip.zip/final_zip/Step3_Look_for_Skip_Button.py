# https://docs.opencv.org/4.x/d4/dc6/tutorial_py_template_matching.html
import os
import cv2
import imageio # required for image to array conversion
import pandas as pd # required for dataframe manipulation
import numpy as np # required for advanced math
from numpy import asarray
from PIL import Image
import random
from matplotlib import pyplot as plt

# Define functions

# Function to convert tif's or jpecs for improved array compatibility
def tif_convert(base_path):
    for infile in os.listdir(base_path):
        if os.path.splitext(infile)[1] == '.tif' or '.jpeg':
            base = os.path.splitext(infile)[0]
            os.rename(base_path + '\\' + infile, base_path + '\\' + base + '.png')
        else:
            base = os.path.splitext(infile)[0]
            print(base + ' is not a .tif or .jpeg and was not converted')
            
# Function to convert image to grayscale
def rgb2gray(rgb):
    return np.dot(rgb[...,:3], [0.2989, 0.5870, 0.1140])
            
# - - - - - - - - - - - - - - - - - - - - - - - - - MAIN - - - - - - - - - - - - - - - - - - - - - - -
parent_dir = r'.\ASU\MFG_598_Python\Class_Project_Skip_Button' # directory with raw images to be transformed
orig_dir = os.path.join(parent_dir, 'Captured_Images')
output_dir = os.path.join(parent_dir, 'Marked_Images')
template_file = os.path.join(parent_dir, 'skip_button_pattern_recoognition.png')
template = cv2.imread(template_file, cv2.IMREAD_GRAYSCALE)
w, h = template.shape[::-1] # define shape to place box around skip buttons that are recognized
 
# convert original images to png to improve compatibility
tif_convert(orig_dir)


pr_threshold = 0.28125
# iterate through images and manipulate and test threshold
for image in os.listdir(orig_dir):
    img_file = os.path.join(orig_dir, image)
    orig_array = cv2.imread(img_file, cv2.IMREAD_GRAYSCALE)
    array = orig_array
    array = array[280:480, 60:270] # reduce image size to reduce computational rigor
    
    array = cv2.medianBlur(array,9) # Apply median blur to de-noise
    #array = rgb2gray(array) # convert to grayscale before averaging
    
    # Sharpen the image using the Laplacian operator 
    array = cv2.Laplacian(array, cv2.CV_64F) 
    array = cv2.Laplacian(array, cv2.CV_64F)
    pixel_threshold = np.percentile(array, 95)
    array[array < pixel_threshold] = 0
    array[array > pixel_threshold] = 256
    # plt.imshow(array, cmap=plt.get_cmap('gray'))
    # plt.show()
    
    # Convert to same data type
    array = cv2.normalize(array, None, 255, 0, cv2.NORM_MINMAX, cv2.CV_8U)
    plt.imshow(array, cmap=plt.get_cmap('gray'))
    plt.show()
    # plt.imshow(template, cmap=plt.get_cmap('gray'))
    # plt.show()
 
    # Apply template Matching
    try:
        res = cv2.matchTemplate(array, template, cv2.TM_CCOEFF_NORMED)
        loc = np.where( res >= pr_threshold)
        print(len(loc[0]))
        hi = np.max(loc)
        print(str(image))
        for pt in zip(*loc[::-1]):
            cv2.rectangle(orig_array, pt, (pt[0] + w, pt[1] + h), (0,0,255), 2)
    except:
        continue

print(pr_threshold)
    #cv2.imwrite(os.path.join(output_dir, image), array)
    
print("Done with image analysis!")
  

    