from datetime import datetime # required to timestamps on files
import os # required for clean file operations
import cv2 # required to get RGB array from camera
from PIL import Image


# Define the directory to save pictures
pic_dir = r".\ASU\MFG_598_Python\Class_Project_Skip_Button\Captured_Images"

# define a video capture object 
cam_port = 1
vid = cv2.VideoCapture(cam_port) 
ret, frame = vid.read()

now = datetime.now()
timestamp = now.strftime("%YYYY-%mm-%dd-%H.%M.%S")
png_path = os.path.join(pic_dir, 'Example_Image_' + timestamp + '.png')

png = Image.fromarray(frame)
png.save(png_path)
vid.release()
