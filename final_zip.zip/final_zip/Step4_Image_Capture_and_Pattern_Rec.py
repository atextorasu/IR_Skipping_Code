import os # required for file IO
import cv2 # required for image manipulation
import pandas as pd # required for dataframe manipulation
import numpy as np # required for advanced math
from matplotlib import pyplot as plt # required to generate plot
# import RPi.GPIO as GPIO # required for Raspberry Pi GPIO pins
from time import sleep # required to wait several ms for GPIO signal
from datetime import datetime # required for data timestamps
import configparser as configParser # used to interpret configuration file
import csv # required for simple CSV reading

# Define functions

# Function to capture image and send it 
def camera_to_array(port):
    vid = cv2.VideoCapture(port) 
    ret, frame = vid.read()
    image_capture = frame
    #image_capture = rgb2gray(frame)
    return image_capture
            
# Function to convert image to grayscale
def array_manipulation(image_feed):
    array = image_feed[280:480, 60:270] # reduce image size to reduce computational rigor
    array = cv2.medianBlur(array,9) # Apply median blur to de-noise
    array = cv2.Laplacian(array, cv2.CV_64F) # Sharpen the image using the Laplacian operator twice
    array = cv2.Laplacian(array, cv2.CV_64F)
    pixel_threshold = np.percentile(array, 95) # define a dynamic threshold
    array[array < pixel_threshold] = 0 # convert darker pixels to black
    array[array > pixel_threshold] = 256 # convert brightest pixels to white
    array = cv2.normalize(array, None, 255, 0, cv2.NORM_MINMAX, cv2.CV_8U) # Convert to same data type (uint 8)
    array = cv2.cvtColor(array, cv2.COLOR_BGR2GRAY)
    return array

def look_for_button(img_array, pr_template):
    plt.imshow(img_array, cmap=plt.get_cmap('gray'))
    plt.show() # Display Inage for troubleshooting purposes
    pr_threshold = 0.28125
    res = cv2.matchTemplate(img_array, pr_template, cv2.TM_CCOEFF_NORMED)
    loc = np.where( res >= pr_threshold)
    if len(loc[0]) > 0:
        print('SKIP BUTTON DETECTED!\nSENDING BUTTON PRESS TO TELEVEISION...')
        return True
    else:
        return False

# Function to send GPIO signal to Arduino
def send_gpio(gpio_port):
    try:
       # GPIO.output(gpio_port, True)
        sleep(0.005)
       # GPIO.output(gpio_port, False)   
    except:
        print("Error while sending GPIO signal")

# Function to log when the system automatically skips ads 
def write2csv(file_path):
    try:
        orig_df = pd.read_csv(file_path,  index_col=False)
        timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S') # log timestamp
        count = orig_df['ad_skipped'].max()
        new_instance = pd.DataFrame.from_dict({'time':[timestamp], 'ad_skipped':[count]})
        new_df = pd.concat([new_instance, orig_df], ignore_index=True)
        new_df.to_csv(file_path, index=False)
    except:
        print('Error Writing the log.csv File. Verify file is not locked.')

# Function to generate plot
def generate_graph_summary(data_file_path, output_dir):
    data_file = pd.read_csv(data_file_path, index_col=False)
    data_file['date'] = pd.to_datetime(data_file['time'], format='%Y-%m-%dT%H:%M:%S')
    date = data_file['date']
    ad = data_file['ad_skipped']
    graph, ax = plt.subplots(figsize=(8, 6))
    plt.title('Total Ads Skipped Using System')
    plt.xlabel('Date_Time')
    plt.ylabel('Total Ads Skipped')
    ax.plot(date, ad)
    plt.savefig(os.path.join(output_dir, 'chart.png'))

# Function to convert timestamps to a list
def read_first_column_to_list(csv_file):
    column_list = []
    with open(csv_file, 'r') as file:
        next(file)
        csv_reader = csv.reader(file)
        for row in csv_reader:
            if row:  # Check if the row is not empty
                column_list.append(str(row[0]))
    return column_list

# Function to write text file with frequency data
def frequency_analysis(timestamps, output_txt):
    hour_frequency = {} # Initialize empty dictionary that will be appnded and written

    for timestamp in timestamps: # Iterate through each timestamp
        dt = datetime.strptime(timestamp, '%Y-%m-%dT%H:%M:%S')
        hour = dt.hour
        hour_frequency[hour] = hour_frequency.get(hour, 0) + 1

    # Write the frequency analysis to a text file
    with open(output_txt, 'w') as file:
        file.write("Hour\tFrequency\n")
        for hour, frequency in sorted(hour_frequency.items()):
            file.write(f"{hour}:00 - {hour + 1}:00\t{frequency}\n")
        file.close()
    
# - - - - - - - - - - - - - - - - - - - - - - - - - MAIN - - - - - - - - - - - - - - - - - - - - - - -
config_file_path = r'.\Documents\ASU\MFG_598_Python\Class_Project_Skip_Button\config.ini'
configParser = configParser.RawConfigParser()   
configParser.read(config_file_path)
parent_dir = configParser.get('SKIP_BUTTON_CONFIG', 'parent_dir')
camera_port = int(configParser.get('SKIP_BUTTON_CONFIG', 'camera_port'))
gpio_port = int(configParser.get('SKIP_BUTTON_CONFIG', 'gpio_port'))
on_switch = bool(configParser.get('SKIP_BUTTON_CONFIG', 'on_switch'))
log_path = os.path.join(parent_dir, 'system_logging.csv')
prior_detection = bool(configParser.get('SKIP_BUTTON_CONFIG', 'prior_detection'))



#GPIO.setmode(GPIO.BCM) # Set GPIO mode to send signals
#GPIO.setup(gpio_port,  GPIO.OUT) # define pin for GPIO

# import the papttern recognition template and convert to array
#    This is performd once when the code execution begins
template_file = os.path.join(parent_dir, 'skip_button_pattern_recoognition.png')
template = cv2.imread(template_file, cv2.IMREAD_GRAYSCALE) 


while on_switch:
    image_feed = camera_to_array(camera_port)
    image_array = array_manipulation(image_feed)
    check = look_for_button(image_array, template)
    print("Nothing Detected")
    sleep(0.001)
    if check:
        if prior_detection:
            print("Ahah!")
            send_gpio(gpio_port)
            write2csv(log_path)
            generate_graph_summary(log_path,parent_dir)
            timestamps = read_first_column_to_list(log_path)
            frequency_analysis(timestamps, os.path.join(parent_dir, 'frequency.txt'))
        prior_detection = True
    else:
        prior_detection = False



