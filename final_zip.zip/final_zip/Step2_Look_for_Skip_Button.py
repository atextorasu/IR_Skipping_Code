import os
import cv2
import imageio # required for image to array conversion
import pandas as pd # required for dataframe manipulation
import numpy as np # required for advanced math
from numpy import asarray
from PIL import Image
import random
from matplotlib import pyplot as plt

# Define functions

# Function to convert tif's or jpecs for improved array compatibility
def tif_convert(base_path):
    for infile in os.listdir(base_path):
        if os.path.splitext(infile)[1] == '.tif' or '.jpeg':
            base = os.path.splitext(infile)[0]
            os.rename(base_path + '\\' + infile, base_path + '\\' + base + '.png')
        else:
            base = os.path.splitext(infile)[0]
            print(base + ' is not a .tif or .jpeg and was not converted')
            
# Function to convert image to grayscale
def rgb2gray(rgb):
    return np.dot(rgb[...,:3], [0.2989, 0.5870, 0.1140])
            
# - - - - - - - - - - - - - - - - - - - - - - - - - MAIN - - - - - - - - - - - - - - - - - - - - - - -
parent_dir = r'.\ASU\MFG_598_Python\Class_Project_Skip_Button' # directory with raw images to be transformed
orig_dir = os.path.join(parent_dir, 'Captured_Images')
output_dir = os.path.join(parent_dir, 'Manipulated_Images') 
testing_dir = os.path.join(parent_dir, 'Added_Images')

# delete any images in output directiry
for file in os.listdir(output_dir):
    os.remove(os.path.join(output_dir, file))
    
# convert original images to png to improve compatibility
tif_convert(orig_dir)
#dffd
# iterate through images and manipulate
for image in os.listdir(orig_dir):
    img_file = os.path.join(orig_dir, image)
    array = cv2.imread(img_file)
    array = array[280:480, 60:270] # reduce image size to reduce computational rigor
    
    # Create the sharpening kernel 
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]]) 
  
    # Sharpen the image 
   # array = cv2.filter2D(array, -1, kernel)
    array = cv2.medianBlur(array,3) # Apply median blur to de-noise
    array = rgb2gray(array) # convert to grayscale before averaging
    
    
    # Sharpen the image using the Laplacian operator 
    array = cv2.Laplacian(array, cv2.CV_64F) 
    array = cv2.Laplacian(array, cv2.CV_64F) 
    # new_array = 256*(array-np.min(array))/(np.max(array)-np.min(array)) 
    # hist, bin_edges = np.histogram(new_array, density=True)
    # plt.hist(new_array, bins=10)
    # plt.title(str(image))
    # plt.show()
    pixel_threshold = np.percentile(array, 95)
    array[array < pixel_threshold] = 0
    array[array > pixel_threshold] = 256
    
    cv2.imwrite(os.path.join(output_dir, image), array)
    
print("Done with Image transformation!")
''' 
# iterate through images and add images together to create an average image
avg_array = np.zeros(shape=array.shape)
for image in os.listdir(testing_dir):
    img_file = os.path.join(testing_dir, image)
    array = cv2.imread(img_file)
    array = rgb2gray(array) # convert to grayscale before averaging
    avg_array = np.add(avg_array, array)

plt.imshow(avg_array, cmap=plt.get_cmap('gray'))
plt.show()    

# Convert array to image and correct brightness
lo = np.min(avg_array)
hi = np.max(avg_array)
brightness_correction = np.random.uniform(low=lo, high=lo, size=avg_array.shape)
avg_array = (np.subtract(avg_array, brightness_correction/hi)*255)
avg_array = avg_array.astype(np.uint8)
                        
data = Image.fromarray(avg_array)
plt.imshow(data, cmap=plt.get_cmap('gray'))
plt.show()

# Extract the skip button from the average array
# This will be used as the common pattern recognition marker
marker = avg_array[80:130, 98:160]
plt.imshow(marker, cmap=plt.get_cmap('gray'))
plt.show()
'''

    